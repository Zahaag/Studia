public interface IPojazd {
void ruszaj();
}
