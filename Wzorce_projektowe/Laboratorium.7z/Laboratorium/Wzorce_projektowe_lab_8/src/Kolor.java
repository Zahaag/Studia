public interface Kolor {
    public String uzyjkoloru();
}
