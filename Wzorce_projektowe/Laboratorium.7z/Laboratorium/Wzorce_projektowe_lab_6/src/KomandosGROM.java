class KomandosGROM implements ICzlowiek {

    @Override
    public void walcz() {
        System.out.println("Nawet nie zauważą co ich zabiło");

    }
    KomandosGROM(){
        System.out.println("Wytrenowano Komandos GROM");
    }
}
