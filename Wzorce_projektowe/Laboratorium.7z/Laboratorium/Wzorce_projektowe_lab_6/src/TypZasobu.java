enum TypZasobu {
    Czlowiek,
    Bron,
    Pojazd

}
