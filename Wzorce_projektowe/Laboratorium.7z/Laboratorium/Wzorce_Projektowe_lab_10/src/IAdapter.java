public interface IAdapter {
    public String stopnienLatwopalnosci();
    public void wyswietl();
}
