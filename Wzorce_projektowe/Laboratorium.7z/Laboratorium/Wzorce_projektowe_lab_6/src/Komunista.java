public class Komunista implements ICzlowiek {
    @Override
    public void walcz() {
System.out.println("Juz jutro u wroga zapanuje rownosc, a burzuazja zawisnie na drzewach...");
    }
    Komunista(){
        System.out.println("Wytrenowano Komunistę");
    }
}
