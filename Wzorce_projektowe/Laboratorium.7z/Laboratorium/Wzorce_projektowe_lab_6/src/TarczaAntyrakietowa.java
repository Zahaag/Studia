public class TarczaAntyrakietowa implements IBron {
    @Override
    public void uzyj() {
        System.out.println("Wszystkie Rakiety zostały odparte!");
    }
}
