import java.awt.*;

public class KolorNiebieski implements Kolor {
    KolorNiebieski(){}

    @Override
    public String toString() {
        return "Kolor Niebieski!";
    }

    @Override
    public String uzyjkoloru() {
        return "Niebieski";
    }
}
