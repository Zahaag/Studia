
package lab2;


public class StanRemanent implements StanSklepu {

    @Override
    public void kupuj() {
        System.out.println("Nie można kupić, bo trwa remanent.");
    }
    
}
