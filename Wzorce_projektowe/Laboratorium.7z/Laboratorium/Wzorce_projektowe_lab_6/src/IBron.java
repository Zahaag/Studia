public interface IBron {
    void uzyj();
}
