abstract class AbstrakcyjnaFigura implements Figura {
    Kolor kolor;
    AbstrakcyjnaFigura(Kolor kolor){this.kolor = kolor;}
}
