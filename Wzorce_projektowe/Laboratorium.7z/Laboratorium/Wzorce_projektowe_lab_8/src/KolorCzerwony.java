public class KolorCzerwony implements Kolor{
    KolorCzerwony(){}
    @Override
    public String toString() {
        return "Kolor Czerwony!";
    }

    @Override
    public String uzyjkoloru() {
        return "Czerwony";
    }

}
