public interface Figura {
   double getObwod();
    double getPole();
}
