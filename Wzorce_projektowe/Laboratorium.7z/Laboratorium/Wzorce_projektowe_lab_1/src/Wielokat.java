
public abstract class Wielokat implements Figura {
    double[] bok;
  abstract void setBok();
   abstract double getBok();
}
