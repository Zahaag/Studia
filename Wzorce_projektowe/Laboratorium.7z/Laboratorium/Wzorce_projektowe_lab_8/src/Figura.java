public interface Figura {
    void rysuj();
}
