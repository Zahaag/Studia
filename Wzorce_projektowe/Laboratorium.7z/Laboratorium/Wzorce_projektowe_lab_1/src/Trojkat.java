
public class Trojkat extends Wielokat{
    double wysokosc;
    Trojkat(double a,double b,double c){
        
    }
    @Override
    void setBok() {
    }

    @Override
    double getBok() {
    }

    @Override
    public double getObwod() {
    }

    @Override
    public double getPole() {
    }
    setWysokosc(){
        
    };
    getWysokosc(){
        
    };
    
}
