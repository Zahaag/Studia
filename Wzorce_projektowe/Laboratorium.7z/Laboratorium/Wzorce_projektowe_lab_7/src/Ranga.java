public enum Ranga {
    GENERAL,
    OFICER,
    SZEREGOWY
}
