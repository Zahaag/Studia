public interface IFabryka {
    Object produkuj(TypZasobu typZasobu);
}
