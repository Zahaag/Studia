public class ImpulsElektromagnetyczny implements IBron {
    @Override
    public void uzyj() {
        System.out.println("Impuls Elektromagnetyczny zaciemni ich na długie lata!");
    }
}
