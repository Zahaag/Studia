public class BSTElement<T> {
    T data;
    BSTElement leftChild, rightChild, parent;
}
