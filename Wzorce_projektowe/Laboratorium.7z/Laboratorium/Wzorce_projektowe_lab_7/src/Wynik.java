public enum Wynik {
    SUKCES,
    PORAZKA,
    BRAK_DOSTEPU

}
