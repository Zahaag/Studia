package lab2;
public interface StanSklepu {
    abstract void kupuj();
}
