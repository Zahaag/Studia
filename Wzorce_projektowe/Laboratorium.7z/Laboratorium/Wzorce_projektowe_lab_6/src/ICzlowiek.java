public interface ICzlowiek {
    void walcz();
}
