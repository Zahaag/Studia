public interface StrategiaSort {
    void sortuj(int[] tab);

}
