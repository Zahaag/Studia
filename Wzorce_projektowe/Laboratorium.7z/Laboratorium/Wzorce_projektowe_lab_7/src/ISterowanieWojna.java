public interface ISterowanieWojna {
    Wynik rozpocznijAtak(String cel);
    Wynik rozpocznijObrone(String miasto);
    Wynik produkujZasoby(String jakie);
}
