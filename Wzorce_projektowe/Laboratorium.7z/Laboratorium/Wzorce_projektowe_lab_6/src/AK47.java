public class AK47 implements IBron{
    @Override
    public void uzyj() {
        System.out.println("AK47 - niezawodna broń terrorystów");
    }
    AK47(){
        System.out.println("Powstała broń AK47");
    }
}