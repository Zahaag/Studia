public class Jelcz44232 implements IPojazd {
    @Override
    public void ruszaj() {
        System.out.println("Nie przebiją się przez nasz pojazd defensywny");
    }
    Jelcz44232(){
        System.out.println("Powstał pojazd Jelcz44232");
    }
}
