public class ZolnierzWOT implements ICzlowiek {
    @Override
    public void walcz() {
        System.out.println("Brać broń do ręki i do obrony!! Ruchy!! Ruchy!!");
    }
    ZolnierzWOT(){
        System.out.println("Wytrenowano żołnierza WOT");
    }
}
