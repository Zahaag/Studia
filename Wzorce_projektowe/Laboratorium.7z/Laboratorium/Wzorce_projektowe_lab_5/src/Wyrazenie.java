public interface Wyrazenie {
   double wartosc();
}
