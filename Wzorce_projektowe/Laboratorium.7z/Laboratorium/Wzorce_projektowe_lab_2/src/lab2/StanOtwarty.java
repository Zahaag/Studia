/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

/**
 *
 * @author Student
 */
public class StanOtwarty implements StanSklepu{

    @Override
    public void kupuj() {
           System.out.println("Kupuj ile wlezie. Promocja trwa tylko prez czas otwarcia sklepu");
    }
    
}
