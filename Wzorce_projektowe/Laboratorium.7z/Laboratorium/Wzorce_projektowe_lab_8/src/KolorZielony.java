public class KolorZielony implements Kolor {
    KolorZielony(){}
    @Override
    public String toString() {
        return "Kolor Zielony!";
    }

    @Override
    public String uzyjkoloru() {
        return "Zielony";
    }
}
